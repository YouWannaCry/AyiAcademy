package com.ayi.spring.rest.serv.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
