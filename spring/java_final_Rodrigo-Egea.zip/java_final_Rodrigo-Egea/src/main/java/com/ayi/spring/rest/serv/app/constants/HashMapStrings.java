package com.ayi.spring.rest.serv.app.constants;

public class HashMapStrings {

    public static final String ERROR_CODE = "Code status";
    public static final String ERROR_MESSAGE = "Message";

}
