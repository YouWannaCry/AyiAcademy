# Final Proyect for the AYI Academy

This project is about a REST API developed in Java with SpringBoot, 
using MySQL as database engine and Swagger to document it.